var x = 10;
var x = 100;
console.log(x);

//Iteraciones

const cielo = document.getElementById("cielo");

for(let i = 0; i<5; i++){
    cielo.innerHTML += '⭐';
}


